package com.example.full_web_converter_to_flutter_app_master

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

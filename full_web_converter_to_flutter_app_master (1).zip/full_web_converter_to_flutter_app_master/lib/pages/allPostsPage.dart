import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:full_web_converter_to_flutter_app_master/utilities/toolsUtilities.dart';

final GlobalKey<WebViewContainerState> webViewKey = GlobalKey<WebViewContainerState>();

class AllPostsPage extends StatefulWidget {
  @override
  AllPostsPageState createState() => AllPostsPageState();
}

class AllPostsPageState extends State<AllPostsPage> {
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    // تحميل البيانات الأولية أو إظهار مؤشر تحميل إن لزم
    Future.delayed(Duration(milliseconds: 500), () {
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("All New Posts"),
        backgroundColor: ToolsUtilities.mainColor,
        centerTitle: false,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () {
              webViewKey.currentState?.reloadWebView();
            },
          ),
        ],
      ),
      body: Stack(
        children: [
          WebViewContainer(key: webViewKey),
          if (isLoading)
            const Center(child: CircularProgressIndicator()),
        ],
      ),
    );
  }
}

class WebViewContainer extends StatefulWidget {
  const WebViewContainer({Key? key}) : super(key: key);

  @override
  WebViewContainerState createState() => WebViewContainerState();
}

class WebViewContainerState extends State<WebViewContainer> {
  late final WebViewController _webViewController;

  @override
  Widget build(BuildContext context) {
    return WebView(
      initialUrl: ToolsUtilities.allPageUrl,
      javascriptMode: JavascriptMode.unrestricted,
      onWebViewCreated: (controller) {
        _webViewController = controller;
      },
    );
  }

  void reloadWebView() {
    _webViewController.reload();
  }
}

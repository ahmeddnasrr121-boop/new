import 'package:flutter/material.dart';
import 'package:full_web_converter_to_flutter_app_master/utilities/toolsUtilities.dart';

class ContactUsPage extends StatefulWidget {
  @override
  _ContactUsPageState createState() => _ContactUsPageState();
}

class _ContactUsPageState extends State<ContactUsPage> {
  // Text controllers
  final TextEditingController nameTextControl = TextEditingController();
  final TextEditingController phoneTextControl = TextEditingController();
  final TextEditingController messageTitleTextControl = TextEditingController();
  final TextEditingController contentTextControl = TextEditingController();

  @override
  void dispose() {
    nameTextControl.dispose();
    phoneTextControl.dispose();
    messageTitleTextControl.dispose();
    contentTextControl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ToolsUtilities.whiteColor,
      appBar: AppBar(
        title: const Text('Contact Us'),
        backgroundColor: ToolsUtilities.mainColor,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: _contactUSCard(),
      ),
    );
  }

  Widget customTextField(
      String hintName, TextEditingController controller, int maxLines) {
    return Padding(
      padding: const EdgeInsets.only(right: 30, left: 30, top: 8),
      child: TextField(
        maxLines: maxLines,
        controller: controller,
        decoration: InputDecoration(
          labelText: hintName,
          labelStyle: TextStyle(color: ToolsUtilities.secondColor),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(color: ToolsUtilities.mainColor),
          ),
          border: const OutlineInputBorder(),
        ),
      ),
    );
  }

  Widget _contactUSCard() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Header image
        Container(
          height: MediaQuery.of(context).size.height * 0.2,
          decoration: BoxDecoration(
            image: DecorationImage(
              image: NetworkImage(ToolsUtilities.contactUsHeaderImage),
              fit: BoxFit.cover,
            ),
          ),
        ),

        // Title
        Padding(
          padding: const EdgeInsets.only(left: 8.0, top: 15),
          child: Text(
            'Contact Us',
            style: TextStyle(
              color: ToolsUtilities.mainColor,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 18.0, top: 10),
          child: Text(
            'We are happy to hear your review',
            style: TextStyle(
              color: ToolsUtilities.secondColor,
              fontSize: 15,
            ),
          ),
        ),

        // Text fields
        customTextField('Enter Your Name', nameTextControl, 1),
        customTextField('Enter Your Phone Number', phoneTextControl, 1),
        customTextField('Enter Your Message Title', messageTitleTextControl, 1),
        customTextField('Enter Your Message Content', contentTextControl, 4),

        // Send button
        Padding(
          padding: const EdgeInsets.all(18.0),
          child: Align(
            alignment: Alignment.bottomRight,
            child: SizedBox(
              width: MediaQuery.of(context).size.width * 0.65,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: ToolsUtilities.mainColor,
                  elevation: 5,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(25.0),
                  ),
                  padding:
                  const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
                ),
                icon: Icon(Icons.email, color: ToolsUtilities.whiteColor),
                label: Text(
                  'Send Via Email',
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                    color: ToolsUtilities.whiteColor,
                  ),
                ),
                onPressed: _sendEmail,
              ),
            ),
          ),
        ),
      ],
    );
  }

  void _sendEmail() {
    final myEmail = ToolsUtilities.email;
    final subject = messageTitleTextControl.text;
    final body = '''
My Name is: ${nameTextControl.text}
My Phone Number is: ${phoneTextControl.text}

${contentTextControl.text}
''';

    final mailUrl =
    Uri.encodeFull('mailto:$myEmail?subject=$subject&body=$body');
    customURlLaunch(mailUrl);

    nameTextControl.clear();
    phoneTextControl.clear();
    messageTitleTextControl.clear();
    contentTextControl.clear();
  }
}

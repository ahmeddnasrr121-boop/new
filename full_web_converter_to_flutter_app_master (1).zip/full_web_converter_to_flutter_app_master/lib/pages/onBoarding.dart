import 'package:flutter/material.dart';
import 'package:full_web_converter_to_flutter_app_master/main.dart';
import 'package:full_web_converter_to_flutter_app_master/pages/starterPage.dart';
import 'package:full_web_converter_to_flutter_app_master/utilities/onBoardingModel.dart';
import 'package:full_web_converter_to_flutter_app_master/utilities/toolsUtilities.dart';
import 'package:shared_preferences/shared_preferences.dart';

List<OnBoardingModel> datautilities = [
  OnBoardingModel('All content will appear from web as App', 'assets/images/2.png'),
  OnBoardingModel('Convert any website to app for iOS and Android', 'assets/images/1.png'),
  OnBoardingModel('Any website update will show immediately', 'assets/images/3.png'),
];

class OnBoarding extends StatefulWidget {
  @override
  _OnBoardingState createState() => _OnBoardingState();
}

class _OnBoardingState extends State<OnBoarding> {
  int currentIndex = 0;
  bool _reachAtEnd = false;
  late PageController _pageController;

  @override
  void initState() {
    super.initState();
    _pageController = PageController(initialPage: 0);
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  Future<void> _updateSeen() async {
    final pref = await SharedPreferences.getInstance();
    await pref.setBool('seen', true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ToolsUtilities.mainColor,
      body: Column(
        children: <Widget>[
          Expanded(
            child: PageView.builder(
              physics: const ClampingScrollPhysics(),
              itemCount: datautilities.length,
              controller: _pageController,
              onPageChanged: (index) {
                setState(() {
                  currentIndex = index;
                  _reachAtEnd = index == datautilities.length - 1;
                });
              },
              itemBuilder: (context, index) {
                return _buildPage(context, index);
              },
            ),
          ),
          Container(
            color: ToolsUtilities.mainColor,
            child: Transform.translate(
              offset: Offset(0, MediaQuery.of(context).size.height * -0.05),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: _drawDots(datautilities.length),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPage(BuildContext context, int index) {
    return Scaffold(
      backgroundColor: ToolsUtilities.mainColor,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: <Widget>[
          TextButton(
            onPressed: () async {
              await _updateSeen();
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => StarterPage()),
              );
            },
            child: Text(
              _reachAtEnd ? 'Start' : 'Skip',
              style: TextStyle(color: ToolsUtilities.whiteColor, fontSize: 18),
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.only(top: 48),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              _customImgBg(index, ToolsUtilities.whiteColor),
              const SizedBox(height: 50),
              Padding(
                padding: const EdgeInsets.all(18.0),
                child: Text(
                  datautilities[index].title,
                  style: TextStyle(
                    color: ToolsUtilities.whiteColor,
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _customImgBg(int index, Color color) {
    return Container(
      width: 250,
      height: 250,
      decoration: BoxDecoration(
        color: color,
        shape: BoxShape.circle,
        image: DecorationImage(
          image: AssetImage(datautilities[index].image),
          fit: BoxFit.contain,
        ),
      ),
    );
  }

  List<Widget> _drawDots(int quantity) {
    return List.generate(quantity, (index) {
      return Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          width: 30,
          height: 10,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: (index == currentIndex)
                ? ToolsUtilities.secondColor
                : ToolsUtilities.whiteColor,
          ),
        ),
      );
    });
  }
}
